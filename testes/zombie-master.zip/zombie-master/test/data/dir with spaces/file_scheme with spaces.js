document.title = "file://";
